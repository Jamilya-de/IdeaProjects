public class Sloth {

    public static void main(String[] args) {
        System.out.println("squeal");
        System.out.println("quitschen");
    }
}
